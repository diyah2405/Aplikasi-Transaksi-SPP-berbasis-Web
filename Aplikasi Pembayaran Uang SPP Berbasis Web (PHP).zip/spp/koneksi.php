<?php
$konek = mysqli_connect('localhost','root','','spp');

?>